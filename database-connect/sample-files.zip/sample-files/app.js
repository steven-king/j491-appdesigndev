
//place functions for data connect here...






function onDeviceReady() {
    //needed only for mobile deployment
    console.log("onDeviceReady()");
        
}

$( document ).ready(function() {
    //for browser use only
    console.log( "document ready!" );
    //function to populate menu  

});


